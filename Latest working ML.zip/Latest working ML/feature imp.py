#!/usr/bin/env python3
"""
=============================================================================
REGIME-AWARE FEATURE DIAGNOSTIC & PRUNING ANALYSIS (v4)
=============================================================================

Builds on v3 with regime-conditional analysis. Each feature is evaluated
in 4 separate regimes (bull_trend, bull_range, bear_trend, bear_range)
in addition to the global view.

WHY THIS MATTERS:
  A feature that contributes 0.001 AUC globally but +0.012 in bear_trend
  is NOT noise — it's a regime-specialist. Pruning it would damage the
  bear_trend ensemble. The old global-only analysis would have flagged
  it as low-importance.

WHAT THIS DOES (8 stages):

  STAGE 1 — GLOBAL FEATURE IMPORTANCE
  STAGE 2 — TEMPORAL STABILITY (per-year & per-quarter)
  STAGE 3 — IC PER FEATURE × REGIME (NEW IN v4)
  STAGE 4 — CROSS-STOCK GENERALIZATION (price-bucket test)
  STAGE 5 — REDUNDANCY (feature-feature correlation)
  STAGE 6 — PER-REGIME PERMUTATION IMPORTANCE (NEW IN v4)
  STAGE 7 — REGIME CONSISTENCY SCORE (NEW IN v4)
  STAGE 8 — STRICT PRUNING RECOMMENDATION (UPDATED IN v4)

STRICT PRUNING LOGIC:
  A feature is DROPPED only if it is noise in ALL 4 regimes AND globally weak
  AND has weak IC. If it has signal in ANY regime, it is KEPT.

OUTPUT FILES:
  feature_diagnostics_full.xlsx
  feature_pruning_recommendation.csv     <- the one you act on
  regime_permutation_importance.csv      NEW
  regime_ic_summary.csv                  NEW
  regime_consistency.csv                 NEW
  feature_importance_global.csv
  feature_ic_by_year.csv
  feature_stability_by_year.csv
  feature_stability_by_quarter.csv
  feature_correlation_matrix.csv
  feature_redundant_pairs.csv
=============================================================================
"""

import json
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from joblib import load
from tqdm import tqdm
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
import lightgbm as lgb

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")

PANEL_PATH = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH = BASE_DIR / "features_train.json"
MODELS_DIR = BASE_DIR / "models"

ROUTER_PATH = MODELS_DIR / "m5_regime_router.joblib"
M5_ENSEMBLE_PATH = MODELS_DIR / "m5_ensemble.joblib"
M5_MODEL_PATH = MODELS_DIR / "m5_classifier.joblib"

OUT_DIR = BASE_DIR / "feature_diagnostics"
OUT_DIR.mkdir(exist_ok=True)

IST = "Asia/Kolkata"
RET_COL = "ret_5d_oc_pct"
TARGET_COL = "top20_vs_bot20_5d"
EMBARGO_DAYS = 5
MIN_CLOSE = 2.0
MIN_AVG20_VOL = 200_000

REGIMES = ["bull_trend", "bull_range", "bear_trend", "bear_range"]

DIAG_LGB_PARAMS = dict(
    n_estimators=400, learning_rate=0.05,
    num_leaves=63, max_depth=6,
    feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1,
    min_data_in_leaf=100,
    reg_alpha=0.1, reg_lambda=5.0,
    n_jobs=-1, random_state=42, verbosity=-1,
)

# Strict pruning thresholds
IC_THRESHOLD = 0.02
PERM_DROP_THRESHOLD = 0.001
STABILITY_THRESHOLD = 0.40
CORR_THRESHOLD = 0.85
GENERALIZATION_RATIO = 0.60
REGIME_EXCEPTIONAL_THRESHOLD = 0.003

# =============================================================================
# LOAD
# =============================================================================

print("=" * 65)
print("REGIME-AWARE FEATURE DIAGNOSTIC & PRUNING ANALYSIS v4")
print("=" * 65)

print("\n[Load] Reading panel and models...")
panel = pd.read_parquet(PANEL_PATH)
panel["timestamp"] = pd.to_datetime(panel["timestamp"]).dt.tz_convert(IST)
panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
panel["date"] = panel["timestamp"].dt.normalize()
panel["year"] = panel["timestamp"].dt.year
panel["quarter"] = panel["timestamp"].dt.to_period("Q").astype(str)

panel["avg20_vol"] = (
    panel.groupby("symbol")["volume"]
         .transform(lambda s: s.rolling(20, min_periods=1).mean())
)

universe_mask = (panel["close"] >= MIN_CLOSE) & (panel["avg20_vol"] >= MIN_AVG20_VOL)
panel = panel[universe_mask].reset_index(drop=True)
print(f"  Panel after universe filter: {len(panel):,} rows")

schema = json.loads(FEATURES_PATH.read_text())
FEATURES = schema["features"]
IMPUTE = {k: float(v) for k, v in schema["impute"].items()}
print(f"  Features: {len(FEATURES)}")

# Auto-detect model architecture
use_regime = False
regime_models = {}
fallback_model = None

if ROUTER_PATH.exists():
    print(f"  Loading regime router from {ROUTER_PATH}")
    router = load(ROUTER_PATH)
    use_regime = True
    fallback_model = router.fallback if hasattr(router, "fallback") else None
    regime_models = router.regime_models if hasattr(router, "regime_models") else {}
    print(f"  Regimes trained: {list(regime_models.keys())}")
    if hasattr(fallback_model, "members"):
        print(f"  Fallback ensemble members: {len(fallback_model.members)}")
elif M5_ENSEMBLE_PATH.exists():
    print(f"  Loading ensemble from {M5_ENSEMBLE_PATH} (no regime router)")
    fallback_model = load(M5_ENSEMBLE_PATH)
else:
    print(f"  Loading single model from {M5_MODEL_PATH}")
    fallback_model = load(M5_MODEL_PATH)

# =============================================================================
# TARGET LABEL
# =============================================================================

def build_target(panel: pd.DataFrame) -> pd.DataFrame:
    if TARGET_COL in panel.columns and panel[TARGET_COL].notna().any():
        return panel
    close = pd.to_numeric(panel["close"], errors="coerce")
    if "ret_5d_oc_pct" in panel.columns and "D_atr14" in panel.columns:
        r5 = pd.to_numeric(panel["ret_5d_oc_pct"], errors="coerce")
        atr_pct = (pd.to_numeric(panel["D_atr14"], errors="coerce")
                   / close.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan) * 100.0
        vol_basis = atr_pct.replace(0, np.nan)
        panel["ret_5d_adj"] = r5 / vol_basis
        panel["rank_5d_pct"] = panel.groupby("timestamp")["ret_5d_adj"].rank(
            method="average", pct=True)
        panel[TARGET_COL] = np.where(
            panel["rank_5d_pct"] >= 0.80, 1,
            np.where(panel["rank_5d_pct"] <= 0.20, 0, np.nan)
        )
    return panel

panel = build_target(panel)
labeled_panel = panel[panel[TARGET_COL].notna()].copy()
print(f"  Labeled rows: {len(labeled_panel):,}")

# =============================================================================
# Helpers
# =============================================================================

def prepare_X(df: pd.DataFrame) -> pd.DataFrame:
    X = df.reindex(columns=FEATURES).copy()
    for c in FEATURES:
        X[c] = pd.to_numeric(X[c], errors="coerce").fillna(IMPUTE.get(c, 0.0))
    return X


def _get_lgb_booster(model):
    if model is None:
        return None
    if hasattr(model, "members") and model.members:
        return _get_lgb_booster(model.members[0])
    if hasattr(model, "calibrated_classifiers_"):
        cc = model.calibrated_classifiers_[0]
        for attr in ["estimator", "base_estimator"]:
            if hasattr(cc, attr):
                est = getattr(cc, attr)
                if hasattr(est, "booster_"):
                    return est.booster_
                if hasattr(est, "_Booster"):
                    return est._Booster
    if hasattr(model, "booster_"):
        return model.booster_
    if hasattr(model, "_Booster"):
        return model._Booster
    return None


def stability_score(imp_df: pd.DataFrame) -> pd.Series:
    means = imp_df.mean(axis=1)
    stds = imp_df.std(axis=1)
    return (1 - (stds / means.replace(0, np.nan))).fillna(0).clip(0, 1)


def _model_score_proba(model, X):
    try:
        return model.predict_proba(X)[:, 1]
    except Exception:
        return None


# =============================================================================
# MATRICES
# =============================================================================

print("\n[Prep] Building feature matrix...")
X_all = prepare_X(labeled_panel)
y_all = labeled_panel[TARGET_COL].astype(int).values
dates_all = labeled_panel["timestamp"].values
years_all = labeled_panel["year"].values
quarters_all = labeled_panel["quarter"].values

n = len(X_all)
split = int(n * 0.8)
tr_idx = np.arange(split)
te_idx = np.arange(split, n)
print(f"  Train: {len(tr_idx):,}  Test: {len(te_idx):,}")

print("\n[Diag Model] Training lightweight diagnostic classifier...")
clf_diag = lgb.LGBMClassifier(**DIAG_LGB_PARAMS)
clf_diag.fit(X_all.iloc[tr_idx], y_all[tr_idx])
p_base = clf_diag.predict_proba(X_all.iloc[te_idx])[:, 1]
base_auc = roc_auc_score(y_all[te_idx], p_base)
print(f"  Baseline test AUC: {base_auc:.4f}")

# =============================================================================
# STAGE 1 - GLOBAL IMPORTANCE
# =============================================================================

print("\n[1/8] GLOBAL IMPORTANCE...")
booster = _get_lgb_booster(fallback_model)
if booster is not None:
    gain = booster.feature_importance(importance_type="gain")
    split_imp = booster.feature_importance(importance_type="split")
    booster_features = booster.feature_name()
    feat_to_gain = dict(zip(booster_features, gain))
    feat_to_split = dict(zip(booster_features, split_imp))
    gain_aligned = [feat_to_gain.get(f, 0) for f in FEATURES]
    split_aligned = [feat_to_split.get(f, 0) for f in FEATURES]
else:
    gain_aligned = clf_diag.booster_.feature_importance(importance_type="gain")
    split_aligned = clf_diag.booster_.feature_importance(importance_type="split")

total_gain = sum(gain_aligned) or 1
total_split = sum(split_aligned) or 1
global_imp = pd.DataFrame({
    "feature": FEATURES,
    "gain": gain_aligned,
    "split": split_aligned,
    "gain_pct": [100.0 * g / total_gain for g in gain_aligned],
    "split_pct": [100.0 * s / total_split for s in split_aligned],
}).sort_values("gain", ascending=False).reset_index(drop=True)
global_imp["gain_rank"] = global_imp.index + 1
global_imp.to_csv(OUT_DIR / "feature_importance_global.csv", index=False)
print(f"  Top 5 by gain: {global_imp.head(5)['feature'].tolist()}")

# =============================================================================
# STAGE 2 - STABILITY
# =============================================================================

print("\n[2/8] STABILITY (per-year & per-quarter)...")

year_imp_cols = {}
for yr in sorted(set(years_all)):
    mask = (years_all == yr)
    if mask.sum() < 5000:
        continue
    Xy = X_all.iloc[mask]
    yy = y_all[mask]
    if len(set(yy)) < 2:
        continue
    clf_yr = lgb.LGBMClassifier(**DIAG_LGB_PARAMS)
    clf_yr.fit(Xy, yy)
    g = clf_yr.booster_.feature_importance(importance_type="gain")
    year_imp_cols[int(yr)] = pd.Series(g, index=FEATURES)
year_imp_df = pd.DataFrame(year_imp_cols)
year_stability = stability_score(year_imp_df)
year_imp_df["stability_yearly"] = year_stability
year_imp_df.to_csv(OUT_DIR / "feature_stability_by_year.csv")
print(f"  Year periods analyzed: {len(year_imp_cols)}")

quarter_imp_cols = {}
for qr in sorted(set(quarters_all)):
    mask = (quarters_all == qr)
    if mask.sum() < 3000:
        continue
    Xq = X_all.iloc[mask]
    yq = y_all[mask]
    if len(set(yq)) < 2:
        continue
    clf_q = lgb.LGBMClassifier(**DIAG_LGB_PARAMS)
    clf_q.fit(Xq, yq)
    g = clf_q.booster_.feature_importance(importance_type="gain")
    quarter_imp_cols[qr] = pd.Series(g, index=FEATURES)
quarter_imp_df = pd.DataFrame(quarter_imp_cols)
quarter_stability = stability_score(quarter_imp_df)
quarter_imp_df["stability_quarterly"] = quarter_stability
quarter_imp_df.to_csv(OUT_DIR / "feature_stability_by_quarter.csv")
print(f"  Quarter periods analyzed: {len(quarter_imp_cols)}")

# =============================================================================
# STAGE 3 - IC PER FEATURE x REGIME
# =============================================================================

print("\n[3/8] IC ANALYSIS (global + per-regime)...")

ret_5d = pd.to_numeric(labeled_panel[RET_COL], errors="coerce").values

# Global IC by year
ic_by_year_rows = []
for feat in tqdm(FEATURES, desc="Global IC"):
    x = X_all[feat].values
    for yr in sorted(set(years_all)):
        mask = (years_all == yr)
        if mask.sum() < 100:
            continue
        try:
            ic, _ = spearmanr(x[mask], ret_5d[mask], nan_policy="omit")
            if not np.isnan(ic):
                ic_by_year_rows.append({"feature": feat, "year": int(yr), "ic": ic})
        except Exception:
            continue
ic_by_year_df = pd.DataFrame(ic_by_year_rows)
ic_by_year_pivot = ic_by_year_df.pivot(index="feature", columns="year", values="ic")
ic_by_year_pivot.to_csv(OUT_DIR / "feature_ic_by_year.csv")

ic_summary_rows = []
for feat in FEATURES:
    sub = ic_by_year_df[ic_by_year_df["feature"] == feat]["ic"]
    if len(sub) == 0:
        ic_summary_rows.append({
            "feature": feat,
            "mean_abs_ic": 0, "ic_pos_pct": 0, "ic_sign_flip": 1.0, "ic_std": 0,
        })
        continue
    pos = (sub > 0).sum()
    neg = (sub < 0).sum()
    sign_flip = min(pos, neg) / max(pos + neg, 1)
    ic_summary_rows.append({
        "feature": feat,
        "mean_abs_ic": sub.abs().mean(),
        "ic_pos_pct": pos / max(len(sub), 1),
        "ic_sign_flip": sign_flip,
        "ic_std": sub.std(),
    })
ic_summary = pd.DataFrame(ic_summary_rows).set_index("feature")

# Per-regime IC
if use_regime and "stock_regime" in labeled_panel.columns:
    print("  Per-regime IC...")
    regime_ic_rows = []
    for feat in tqdm(FEATURES, desc="Regime IC"):
        x = X_all[feat].values
        row = {"feature": feat}
        for r in REGIMES:
            mask = (labeled_panel["stock_regime"].values == r)
            if mask.sum() < 1000:
                row[f"ic_{r}"] = np.nan
                continue
            try:
                ic, _ = spearmanr(x[mask], ret_5d[mask], nan_policy="omit")
                row[f"ic_{r}"] = ic if not np.isnan(ic) else np.nan
            except Exception:
                row[f"ic_{r}"] = np.nan
        regime_ic_rows.append(row)
    regime_ic_df = pd.DataFrame(regime_ic_rows).set_index("feature")
    regime_ic_df.to_csv(OUT_DIR / "regime_ic_summary.csv")
    print(f"  Saved: regime_ic_summary.csv")
else:
    regime_ic_df = pd.DataFrame(
        index=FEATURES,
        columns=[f"ic_{r}" for r in REGIMES],
        data=np.nan
    )

# =============================================================================
# STAGE 4 - GENERALIZATION
# =============================================================================

print("\n[4/8] CROSS-STOCK GENERALIZATION...")

median_price = labeled_panel["close"].median()
low_price_mask = (labeled_panel["close"] < median_price).values
high_price_mask = ~low_price_mask

clf_low = lgb.LGBMClassifier(**DIAG_LGB_PARAMS)
clf_low.fit(X_all[low_price_mask], y_all[low_price_mask])
imp_low = clf_low.booster_.feature_importance(importance_type="gain")

clf_high = lgb.LGBMClassifier(**DIAG_LGB_PARAMS)
clf_high.fit(X_all[high_price_mask], y_all[high_price_mask])
imp_high = clf_high.booster_.feature_importance(importance_type="gain")

gen_rows = []
sum_low = sum(imp_low) or 1
sum_high = sum(imp_high) or 1
for i, feat in enumerate(FEATURES):
    li = imp_low[i] / sum_low
    hi = imp_high[i] / sum_high
    gen_ratio = min(li, hi) / max(li, hi) if max(li, hi) > 0 else 0
    gen_rows.append({
        "feature": feat,
        "low_price_imp_pct": li * 100,
        "high_price_imp_pct": hi * 100,
        "avg_generalization_ratio": gen_ratio,
    })
gen_df = pd.DataFrame(gen_rows)
gen_df.to_csv(OUT_DIR / "feature_generalization.csv", index=False)

# =============================================================================
# STAGE 5 - REDUNDANCY
# =============================================================================

print("\n[5/8] REDUNDANCY ANALYSIS...")

if len(X_all) > 100_000:
    sample_idx = np.random.RandomState(42).choice(len(X_all), 100_000, replace=False)
    X_corr = X_all.iloc[sample_idx]
else:
    X_corr = X_all

corr_mat = X_corr.corr(method="spearman")
corr_mat.to_csv(OUT_DIR / "feature_correlation_matrix.csv")

high_corr_pairs = []
for i, fi in enumerate(FEATURES):
    for j, fj in enumerate(FEATURES):
        if j <= i:
            continue
        c = corr_mat.iloc[i, j]
        if pd.notna(c) and abs(c) >= CORR_THRESHOLD:
            ic_i = ic_summary.loc[fi, "mean_abs_ic"] if fi in ic_summary.index else 0
            ic_j = ic_summary.loc[fj, "mean_abs_ic"] if fj in ic_summary.index else 0
            keep = fi if ic_i >= ic_j else fj
            drop = fj if keep == fi else fi
            high_corr_pairs.append({
                "feature_a": fi, "feature_b": fj,
                "correlation": c, "keep": keep, "drop_candidate": drop,
                "reason": f"{keep} has higher mean |IC|",
            })
corr_pairs_df = pd.DataFrame(high_corr_pairs)
corr_pairs_df.to_csv(OUT_DIR / "feature_redundant_pairs.csv", index=False)
print(f"  Found {len(high_corr_pairs)} redundant pairs (|r| >= {CORR_THRESHOLD})")

# =============================================================================
# STAGE 6 - PER-REGIME PERMUTATION IMPORTANCE
# =============================================================================

print("\n[6/8] PER-REGIME PERMUTATION IMPORTANCE (full data)...")

# Global permutation first
print("  [6.1] Global permutation...")
X_te = X_all.iloc[te_idx].copy()
y_te = y_all[te_idx]
global_perm_rows = []
for feat in tqdm(FEATURES, desc="Global perm"):
    X_shuf = X_te.copy()
    X_shuf[feat] = X_shuf[feat].sample(frac=1, random_state=42).values
    try:
        p_shuf = clf_diag.predict_proba(X_shuf)[:, 1]
        auc_shuf = roc_auc_score(y_te, p_shuf)
        auc_drop = base_auc - auc_shuf
    except Exception:
        auc_drop = np.nan
    global_perm_rows.append({
        "feature": feat,
        "auc_base": round(base_auc, 5),
        "auc_after_shuffle": round(base_auc - (auc_drop if pd.notna(auc_drop) else 0), 5),
        "auc_drop_global": round(auc_drop, 5) if pd.notna(auc_drop) else np.nan,
    })
global_perm_df = pd.DataFrame(global_perm_rows).set_index("feature")
global_perm_df.to_csv(OUT_DIR / "feature_permutation_importance.csv")

# Per-regime permutation
regime_perm_results = {r: {} for r in REGIMES}
regime_aucs = {}

if use_regime and "stock_regime" in labeled_panel.columns:
    for r in REGIMES:
        model = regime_models.get(r) or fallback_model
        if model is None:
            print(f"  [6.x] {r}: no model, skipping")
            continue

        mask = (labeled_panel["stock_regime"].values == r)
        n_regime = mask.sum()
        if n_regime < 1000:
            print(f"  [6.x] {r}: only {n_regime} rows, skipping")
            continue

        X_r = X_all.iloc[mask]
        y_r = y_all[mask]
        if len(set(y_r)) < 2:
            print(f"  [6.x] {r}: one-class, skipping")
            continue

        n_r = len(X_r)
        r_split = int(n_r * 0.8)
        X_r_te = X_r.iloc[r_split:]
        y_r_te = y_r[r_split:]

        if len(X_r_te) < 500 or len(set(y_r_te)) < 2:
            X_r_te = X_r
            y_r_te = y_r

        try:
            p_base_r = _model_score_proba(model, X_r_te)
            base_auc_r = roc_auc_score(y_r_te, p_base_r)
        except Exception as e:
            print(f"  [6.x] {r}: baseline failed ({e}), skipping")
            continue

        regime_aucs[r] = base_auc_r
        print(f"  [6.{REGIMES.index(r)+2}] {r}: n_test={len(X_r_te):,}  base_AUC={base_auc_r:.4f}")

        for feat in tqdm(FEATURES, desc=f"Perm {r}"):
            X_shuf = X_r_te.copy()
            X_shuf[feat] = X_shuf[feat].sample(frac=1, random_state=42).values
            try:
                p_shuf = _model_score_proba(model, X_shuf)
                auc_shuf = roc_auc_score(y_r_te, p_shuf)
                auc_drop = base_auc_r - auc_shuf
            except Exception:
                auc_drop = np.nan
            regime_perm_results[r][feat] = auc_drop

regime_perm_data = {"feature": FEATURES}
for r in REGIMES:
    regime_perm_data[f"auc_drop_{r}"] = [
        regime_perm_results[r].get(f, np.nan) for f in FEATURES
    ]
regime_perm_df = pd.DataFrame(regime_perm_data).set_index("feature")
regime_perm_df["auc_drop_global"] = global_perm_df["auc_drop_global"]
regime_perm_df.to_csv(OUT_DIR / "regime_permutation_importance.csv")
print(f"  Saved: regime_permutation_importance.csv")

# =============================================================================
# STAGE 7 - REGIME CONSISTENCY SCORE
# =============================================================================

print("\n[7/8] REGIME CONSISTENCY SCORE...")

consistency_rows = []
for feat in FEATURES:
    regime_drops = [regime_perm_results[r].get(feat, np.nan) for r in REGIMES]
    valid = [d for d in regime_drops if pd.notna(d)]
    if not valid:
        consistency_rows.append({
            "feature": feat,
            "consistency_score": 0.0,
            "max_regime_drop": np.nan,
            "min_regime_drop": np.nan,
            "mean_regime_drop": np.nan,
            "exceptional_regime": "",
            "regime_specialist": False,
            "is_dead_everywhere": True,
        })
        continue

    max_drop = max(valid)
    min_drop = min(valid)
    mean_drop = np.mean(valid)
    std_drop = np.std(valid) + 1e-9
    consistency = max(0.0, 1.0 - (std_drop / (abs(mean_drop) + 1e-6)))

    drop_dict = {r: regime_perm_results[r].get(feat, np.nan) for r in REGIMES}
    drop_dict = {r: d for r, d in drop_dict.items() if pd.notna(d)}
    if drop_dict:
        exceptional = max(drop_dict, key=drop_dict.get)
        if drop_dict[exceptional] < PERM_DROP_THRESHOLD:
            exceptional = ""
    else:
        exceptional = ""

    is_dead = all(d < PERM_DROP_THRESHOLD for d in valid)
    is_specialist = (max_drop >= REGIME_EXCEPTIONAL_THRESHOLD and
                     min_drop < PERM_DROP_THRESHOLD)

    consistency_rows.append({
        "feature": feat,
        "consistency_score": round(min(consistency, 1.0), 3),
        "max_regime_drop": round(max_drop, 5),
        "min_regime_drop": round(min_drop, 5),
        "mean_regime_drop": round(mean_drop, 5),
        "exceptional_regime": exceptional,
        "regime_specialist": is_specialist,
        "is_dead_everywhere": is_dead,
    })
consistency_df = pd.DataFrame(consistency_rows)
consistency_df.to_csv(OUT_DIR / "regime_consistency.csv", index=False)

n_specialists = int(consistency_df["regime_specialist"].sum())
n_dead = int(consistency_df["is_dead_everywhere"].sum())
print(f"  Regime-specialist features: {n_specialists} (strong in 1+ regime, weak in others)")
print(f"  Dead-everywhere features:   {n_dead} (candidates for DROP)")

# =============================================================================
# STAGE 8 - STRICT PRUNING RECOMMENDATION
# =============================================================================

print("\n[8/8] STRICT PRUNING RECOMMENDATION...")

# Assemble master table
rec = global_imp[["feature", "gain_pct", "split_pct", "gain_rank"]].copy()

ic_summary_reset = ic_summary.reset_index()
rec = rec.merge(
    ic_summary_reset[["feature", "mean_abs_ic", "ic_pos_pct", "ic_sign_flip", "ic_std"]],
    on="feature", how="left"
)

ys = year_stability.reset_index()
ys.columns = ["feature", "stability_yearly"]
rec = rec.merge(ys, on="feature", how="left")

qs = quarter_stability.reset_index()
qs.columns = ["feature", "stability_quarterly"]
rec = rec.merge(qs, on="feature", how="left")

rec = rec.merge(gen_df[["feature", "avg_generalization_ratio"]], on="feature", how="left")

global_perm_reset = global_perm_df.reset_index()
rec = rec.merge(global_perm_reset[["feature", "auc_drop_global"]], on="feature", how="left")

rec = rec.merge(consistency_df, on="feature", how="left")

# Merge per-regime auc_drop columns
for r in REGIMES:
    col = f"auc_drop_{r}"
    rec[col] = rec["feature"].map(regime_perm_df[col].to_dict())

# Merge per-regime IC columns
for r in REGIMES:
    col = f"ic_{r}"
    if col in regime_ic_df.columns:
        rec[col] = rec["feature"].map(regime_ic_df[col].to_dict())


def strict_recommend(row):
    regime_drops = [row.get(f"auc_drop_{r}") for r in REGIMES]
    regime_drops = [d for d in regime_drops if pd.notna(d)]

    regime_ics = [row.get(f"ic_{r}") for r in REGIMES]
    regime_ics = [abs(ic) for ic in regime_ics if pd.notna(ic)]

    global_perm = row.get("auc_drop_global", 0)
    global_perm = global_perm if pd.notna(global_perm) else 0
    mean_abs_ic = row.get("mean_abs_ic", 0)
    mean_abs_ic = mean_abs_ic if pd.notna(mean_abs_ic) else 0

    if regime_drops and max(regime_drops) >= REGIME_EXCEPTIONAL_THRESHOLD:
        return "KEEP"
    if regime_ics and max(regime_ics) >= IC_THRESHOLD * 2:
        return "KEEP"
    if global_perm >= PERM_DROP_THRESHOLD * 3:
        return "KEEP"
    if mean_abs_ic >= IC_THRESHOLD * 2:
        return "KEEP"

    is_dead_all_regimes = bool(regime_drops) and all(d < PERM_DROP_THRESHOLD for d in regime_drops)
    is_dead_global = global_perm < PERM_DROP_THRESHOLD
    is_weak_ic = mean_abs_ic < IC_THRESHOLD

    if is_dead_all_regimes and is_dead_global and is_weak_ic:
        return "DROP"

    return "REVIEW"


def explain_recommendation(row):
    rec_val = row["recommendation"]
    parts = []
    regime_drops = {r: row.get(f"auc_drop_{r}") for r in REGIMES}
    valid_drops = [(r, d) for r, d in regime_drops.items() if pd.notna(d)]
    max_regime = max(valid_drops, key=lambda x: x[1]) if valid_drops else (None, None)

    if rec_val == "KEEP":
        if max_regime[0] and max_regime[1] is not None and max_regime[1] >= REGIME_EXCEPTIONAL_THRESHOLD:
            parts.append(f"Strong in {max_regime[0]} ({max_regime[1]:.4f})")
        if pd.notna(row.get("mean_abs_ic")) and row["mean_abs_ic"] >= IC_THRESHOLD * 2:
            parts.append(f"Strong IC ({row['mean_abs_ic']:.4f})")
        if pd.notna(row.get("auc_drop_global")) and row["auc_drop_global"] >= PERM_DROP_THRESHOLD * 3:
            parts.append(f"Strong global perm ({row['auc_drop_global']:.4f})")
    elif rec_val == "DROP":
        parts.append("Dead in all regimes")
        if pd.notna(row.get("mean_abs_ic")):
            parts.append(f"Weak IC ({row['mean_abs_ic']:.4f})")
        if pd.notna(row.get("auc_drop_global")):
            parts.append(f"Weak global perm ({row['auc_drop_global']:.4f})")
    else:
        if max_regime[0] and max_regime[1] is not None:
            parts.append(f"Best in {max_regime[0]} ({max_regime[1]:.4f}) but inconsistent")
        else:
            parts.append("Marginal evidence")

    return " | ".join(parts) if parts else ""


rec["recommendation"] = rec.apply(strict_recommend, axis=1)
rec["reason"] = rec.apply(explain_recommendation, axis=1)

order = {"DROP": 0, "REVIEW": 1, "KEEP": 2}
rec["sort_order"] = rec["recommendation"].map(order)
rec = rec.sort_values(["sort_order", "gain_rank"]).drop("sort_order", axis=1)

round_cols = [
    "gain_pct", "split_pct", "mean_abs_ic", "ic_pos_pct", "ic_sign_flip", "ic_std",
    "stability_yearly", "stability_quarterly",
    "avg_generalization_ratio", "auc_drop_global", "consistency_score",
    "max_regime_drop", "min_regime_drop", "mean_regime_drop",
]
for col in round_cols:
    if col in rec.columns:
        rec[col] = pd.to_numeric(rec[col], errors="coerce").round(4)

for r in REGIMES:
    for col in [f"auc_drop_{r}", f"ic_{r}"]:
        if col in rec.columns:
            rec[col] = pd.to_numeric(rec[col], errors="coerce").round(4)

rec.to_csv(OUT_DIR / "feature_pruning_recommendation.csv", index=False)

# =============================================================================
# EXCEL REPORT
# =============================================================================

print("\nSaving Excel report...")
excel_path = OUT_DIR / "feature_diagnostics_full.xlsx"
with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
    rec.to_excel(writer, sheet_name="0 Pruning Recommendation", index=False)
    global_imp.to_excel(writer, sheet_name="1 Global Importance", index=False)
    ic_by_year_pivot.to_excel(writer, sheet_name="2 IC by Year")
    ic_summary.to_excel(writer, sheet_name="3 IC Summary")
    regime_ic_df.to_excel(writer, sheet_name="4 IC per Regime")
    year_imp_df.to_excel(writer, sheet_name="5 Stability by Year")
    quarter_imp_df.to_excel(writer, sheet_name="6 Stability by Quarter")
    gen_df.to_excel(writer, sheet_name="7 Generalization", index=False)
    corr_pairs_df.to_excel(writer, sheet_name="8 Redundant Pairs", index=False)
    global_perm_df.to_excel(writer, sheet_name="9 Global Permutation")
    regime_perm_df.to_excel(writer, sheet_name="10 Regime Permutation")
    consistency_df.to_excel(writer, sheet_name="11 Regime Consistency", index=False)
print(f"  Saved: {excel_path}")

# =============================================================================
# SUMMARY
# =============================================================================

drop_list = rec[rec["recommendation"] == "DROP"]["feature"].tolist()
review_list = rec[rec["recommendation"] == "REVIEW"]["feature"].tolist()
keep_list = rec[rec["recommendation"] == "KEEP"]["feature"].tolist()

print("\n" + "=" * 65)
print("SUMMARY")
print("=" * 65)
print(f"\nFeatures total: {len(FEATURES)}")
print(f"  KEEP    : {len(keep_list):4d}  ({100*len(keep_list)/len(FEATURES):.1f}%)")
print(f"  REVIEW  : {len(review_list):4d}  ({100*len(review_list)/len(FEATURES):.1f}%)")
print(f"  DROP    : {len(drop_list):4d}  ({100*len(drop_list)/len(FEATURES):.1f}%)")
print(f"\nRegime-specialist features (preserved by strict mode): {n_specialists}")

if use_regime and regime_aucs:
    print("\nBaseline AUC by regime:")
    for r in REGIMES:
        if r in regime_aucs:
            print(f"  {r:15} : {regime_aucs[r]:.4f}")

if drop_list:
    print(f"\nTop 10 DROP candidates:")
    for f in drop_list[:10]:
        row = rec[rec["feature"] == f].iloc[0]
        print(f"  {f:40} {row['reason']}")

if n_specialists > 0:
    print(f"\nTop 10 regime-specialist features:")
    specialists = consistency_df[consistency_df["regime_specialist"]].head(10)
    for _, row in specialists.iterrows():
        print(f"  {row['feature']:40} strong in: {row['exceptional_regime']}")

print(f"\nAll outputs: {OUT_DIR}")
print(f"Main file:   {OUT_DIR / 'feature_pruning_recommendation.csv'}")
print("\n" + "=" * 65)
print("Done.")
print("=" * 65)