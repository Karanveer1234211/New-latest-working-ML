#!/usr/bin/env python3
"""
=============================================================================
STRATEGY LAB - F3 + Technical Level Filters (Tier 1 + Tier 2)
=============================================================================

Tests F3 with technical level filters computed from your existing data:

TIER 1 (high confidence filters):
  - VWAP: entry above/below volume-weighted average price
  - CPR: alignment with Central Pivot Range (Pivot, TC, BC)
  - Gap: gap-up/down magnitude and direction
  - MA distance: overextension from 20-day moving average

TIER 2 (medium confidence filters):
  - Standard pivots: R1, R2, S1, S2 levels
  - PDH/PDL: previous day high and low
  - VPOC: volume point of control (most-traded price)

For each filter, tests:
  - F3 alone (baseline)
  - F3 + filter individually
  - F3 + best filter combinations

DATA SOURCES:
  - extracted_paths from orb_workshop (intraday bars per signal)
  - daily cache files (for computing CPR, pivots, MA, PDH/PDL)
  - intraday volumes (for VWAP, VPOC)

OUTPUTS:
  - strategy_lab_results.csv
  - strategy_lab_report.xlsx (sheets: individual, combinations, ranked)

USAGE:
  python strategy_lab.py
=============================================================================
"""

import argparse
import warnings
from pathlib import Path
from datetime import datetime
import time

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# =============================================================================
# CONFIG
# =============================================================================

BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
WORKSHOP_OUT = BASE_DIR / "orb_workshop_results"
EXTRACTED_PATHS = WORKSHOP_OUT / "default_paths.parquet"

DAILY_CACHE_DIR = Path(r"C:\Users\karanvsi\Desktop\Pycharm\Cache\cache_daily_new")

OUT_DIR = BASE_DIR / "strategy_lab_results"
OUT_DIR.mkdir(parents=True, exist_ok=True)

IST = "Asia/Kolkata"
HOLDING_DAYS = 5
SHARPE_PERIODS_PER_YEAR = 50

COST_PER_ROUND_TRIP_PCT = 0.35
MIN_TRADES_FOR_REPORT = 30

# =============================================================================
# DAILY DATA LOADER (with caching)
# =============================================================================

_daily_cache_memo = {}  # symbol -> daily DataFrame


def load_daily_data(symbol: str) -> pd.DataFrame:
    """Load daily OHLC for a symbol. Cached after first load."""
    if symbol in _daily_cache_memo:
        return _daily_cache_memo[symbol]

    # Try common filename patterns
    candidates = [
        DAILY_CACHE_DIR / f"{symbol}.parquet",
        DAILY_CACHE_DIR / f"{symbol}_daily.parquet",
        DAILY_CACHE_DIR / f"{symbol}.csv",
        DAILY_CACHE_DIR / f"{symbol}_daily.csv",
    ]

    df = None
    for path in candidates:
        if path.exists():
            try:
                if path.suffix == ".parquet":
                    df = pd.read_parquet(path)
                else:
                    df = pd.read_csv(path)
                break
            except Exception:
                continue

    if df is None or len(df) == 0:
        _daily_cache_memo[symbol] = None
        return None

    # Standardize columns
    df.columns = [c.lower() for c in df.columns]
    if "timestamp" in df.columns:
        df["date"] = pd.to_datetime(df["timestamp"])
    elif "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
    else:
        _daily_cache_memo[symbol] = None
        return None

    if df["date"].dt.tz is not None:
        df["date"] = df["date"].dt.tz_localize(None)
    df["date"] = df["date"].dt.normalize()

    # Ensure OHLC columns
    needed = ["open", "high", "low", "close"]
    if not all(c in df.columns for c in needed):
        _daily_cache_memo[symbol] = None
        return None

    df = df[["date"] + needed + (["volume"] if "volume" in df.columns else [])]
    df = df.sort_values("date").reset_index(drop=True)

    _daily_cache_memo[symbol] = df
    return df


def compute_levels_for_signal(symbol: str, signal_date) -> dict:
    """
    Compute all technical levels for a given (symbol, signal_date).
    Returns dict with CPR, pivots, PDH/PDL, MA20, etc.

    These are computed from the DAILY data, based on the PREVIOUS day's OHLC
    (i.e., the close before signal_date).
    """
    daily = load_daily_data(symbol)
    if daily is None or len(daily) < 25:
        return {}

    signal_date = pd.Timestamp(signal_date).normalize()
    if signal_date.tz is not None:
        signal_date = signal_date.tz_localize(None)

    # Find the most recent daily bar AT OR BEFORE signal_date
    daily_filtered = daily[daily["date"] <= signal_date]
    if len(daily_filtered) < 21:  # need at least 20 prior days for MA
        return {}

    # The signal_date is the close-of-day we're seeing.
    # T+1 (next morning) uses these prior-day-close-derived levels.
    last_day = daily_filtered.iloc[-1]
    prev_high = last_day["high"]
    prev_low = last_day["low"]
    prev_close = last_day["close"]
    prev_open = last_day["open"]

    # === CPR Levels ===
    pivot = (prev_high + prev_low + prev_close) / 3
    bc = (prev_high + prev_low) / 2
    tc = (pivot - bc) + pivot  # TC = 2P - BC
    cpr_width = tc - bc
    cpr_width_pct = (cpr_width / pivot * 100) if pivot > 0 else 0

    # === Standard Pivots ===
    r1 = 2 * pivot - prev_low
    r2 = pivot + (prev_high - prev_low)
    r3 = prev_high + 2 * (pivot - prev_low)
    s1 = 2 * pivot - prev_high
    s2 = pivot - (prev_high - prev_low)
    s3 = prev_low - 2 * (prev_high - pivot)

    # === Previous Day Levels ===
    pdh = prev_high
    pdl = prev_low
    pdc = prev_close

    # === Moving Averages (using last 20 daily bars before signal_date) ===
    last20 = daily_filtered.tail(20)
    ma20 = last20["close"].mean()
    ma20_high = last20["high"].max()
    ma20_low = last20["low"].min()

    # === Distance from MA20 (as %) ===
    dist_from_ma20_pct = ((prev_close / ma20) - 1) * 100 if ma20 > 0 else 0

    return {
        "pivot": pivot,
        "tc": tc,
        "bc": bc,
        "cpr_width": cpr_width,
        "cpr_width_pct": cpr_width_pct,
        "r1": r1, "r2": r2, "r3": r3,
        "s1": s1, "s2": s2, "s3": s3,
        "pdh": pdh, "pdl": pdl, "pdc": pdc,
        "prev_open": prev_open,
        "ma20": ma20,
        "ma20_high": ma20_high,
        "ma20_low": ma20_low,
        "dist_from_ma20_pct": dist_from_ma20_pct,
    }


# =============================================================================
# INTRADAY ANALYTICS (VWAP, VPOC)
# =============================================================================

def compute_vwap_at_entry(sig, entry_idx):
    """VWAP computed from start of day to entry bar."""
    bar_highs = np.array(sig["bar_highs"])
    bar_lows = np.array(sig["bar_lows"])
    bar_closes = np.array(sig["bar_closes"])
    bar_volumes = np.array(sig.get("bar_volumes", [0] * len(bar_highs)))
    bar_days = np.array(sig["bar_days"])

    # Limit to bars on T+1 (day 0) up to entry_idx
    same_day_mask = bar_days[:entry_idx + 1] == 0

    bv = bar_volumes[:entry_idx + 1][same_day_mask]
    bh = bar_highs[:entry_idx + 1][same_day_mask]
    bl = bar_lows[:entry_idx + 1][same_day_mask]
    bc = bar_closes[:entry_idx + 1][same_day_mask]

    cum_vol = bv.sum()
    if cum_vol <= 0 or len(bv) == 0:
        return bar_closes[entry_idx]

    typical = (bh + bl + bc) / 3
    return (typical * bv).sum() / cum_vol


def compute_vpoc_at_entry(sig, entry_idx, price_buckets=20):
    """
    Approximate VPOC using TPO-style distribution.
    For each bar before entry, distribute volume evenly across high-low range.
    Returns the price level (mid of bucket) with most volume.
    """
    bar_highs = np.array(sig["bar_highs"])
    bar_lows = np.array(sig["bar_lows"])
    bar_volumes = np.array(sig.get("bar_volumes", [0] * len(bar_highs)))
    bar_days = np.array(sig["bar_days"])

    same_day_mask = bar_days[:entry_idx + 1] == 0
    bh = bar_highs[:entry_idx + 1][same_day_mask]
    bl = bar_lows[:entry_idx + 1][same_day_mask]
    bv = bar_volumes[:entry_idx + 1][same_day_mask]

    if len(bh) < 2 or bv.sum() <= 0:
        return None

    day_high = bh.max()
    day_low = bl.min()
    if day_high <= day_low:
        return None

    bucket_size = (day_high - day_low) / price_buckets
    if bucket_size <= 0:
        return None

    volume_by_bucket = np.zeros(price_buckets)
    for i in range(len(bh)):
        b_high = bh[i]
        b_low = bl[i]
        b_vol = bv[i]

        if b_high == b_low:
            # Point trade, assign to one bucket
            idx = min(int((b_high - day_low) / bucket_size), price_buckets - 1)
            volume_by_bucket[idx] += b_vol
        else:
            # Distribute volume across buckets the bar spans
            low_bucket = max(0, int((b_low - day_low) / bucket_size))
            high_bucket = min(price_buckets - 1, int((b_high - day_low) / bucket_size))
            n_buckets = high_bucket - low_bucket + 1
            vol_per_bucket = b_vol / n_buckets
            for k in range(low_bucket, high_bucket + 1):
                volume_by_bucket[k] += vol_per_bucket

    vpoc_bucket = np.argmax(volume_by_bucket)
    vpoc_price = day_low + (vpoc_bucket + 0.5) * bucket_size
    return vpoc_price


# =============================================================================
# F3 ENTRY LOGIC
# =============================================================================

def get_f3_entry(sig):
    """F3: 15-min range + 30-min reversal check. Returns (entry_idx, entry_price)."""
    if not isinstance(sig.get("bar_timestamps"), (list, np.ndarray)):
        return None, None

    bar_closes = np.array(sig["bar_closes"])
    bar_days = np.array(sig["bar_days"])
    n_bars = len(bar_closes)

    orh = sig.get("t1_orh_15min")
    orl = sig.get("t1_orl_15min")
    if pd.isna(orh) or pd.isna(orl) or orh <= orl:
        return None, None

    for i in range(n_bars):
        day = int(bar_days[i])
        if day != 0:
            continue
        if np.sum(bar_days[:i] == 0) < 3:
            continue

        if bar_closes[i] > orh:
            reversal = False
            for j in range(i + 1, min(i + 7, n_bars)):
                if bar_closes[j] < orh:
                    reversal = True
                    break
            if not reversal:
                return i, bar_closes[i]

    return None, None


def simulate_f3_trade(sig, entry_idx, entry_price):
    """Simulate F3 trade after entry: ORL stop, +5% target, T+5 force exit."""
    if entry_idx is None or entry_price is None or entry_price <= 0:
        return None

    bar_highs = np.array(sig["bar_highs"])
    bar_lows = np.array(sig["bar_lows"])
    bar_closes = np.array(sig["bar_closes"])
    bar_days = np.array(sig["bar_days"])
    n_bars = len(bar_highs)

    orl = sig.get("t1_orl_15min")
    if pd.isna(orl) or orl >= entry_price:
        return None

    stop_price = orl
    target_price = entry_price * 1.05

    exit_price = None
    exit_idx = None
    trigger_reason = None
    mae_pct = 0.0
    mfe_pct = 0.0

    for j in range(entry_idx + 1, n_bars):
        low_pct = (bar_lows[j] / entry_price - 1) * 100
        high_pct = (bar_highs[j] / entry_price - 1) * 100
        if low_pct < mae_pct:
            mae_pct = low_pct
        if high_pct > mfe_pct:
            mfe_pct = high_pct

        if bar_lows[j] <= stop_price:
            exit_price = stop_price
            exit_idx = j
            trigger_reason = "stop"
            break
        if bar_highs[j] >= target_price:
            exit_price = target_price
            exit_idx = j
            trigger_reason = "target"
            break
        if bar_days[j] >= HOLDING_DAYS - 1:
            if j == n_bars - 1 or bar_days[j + 1] > HOLDING_DAYS - 1:
                exit_price = bar_closes[j]
                exit_idx = j
                trigger_reason = "time"
                break

    if exit_price is None:
        exit_price = bar_closes[-1]
        exit_idx = n_bars - 1
        trigger_reason = "time"

    gross_ret = (exit_price / entry_price - 1) * 100
    if gross_ret > 50 or gross_ret < -50:
        return None

    net_ret = gross_ret - COST_PER_ROUND_TRIP_PCT
    days_held = int(bar_days[exit_idx]) - int(bar_days[entry_idx])

    return {
        "entry_price": entry_price,
        "exit_price": exit_price,
        "gross_ret_pct": gross_ret,
        "net_ret_pct": net_ret,
        "days_held": days_held,
        "trigger_reason": trigger_reason,
        "mae_pct": mae_pct,
        "mfe_pct": mfe_pct,
    }


# =============================================================================
# ENRICH PATHS WITH LEVELS (do this once)
# =============================================================================

def enrich_signals_with_levels(paths_df):
    """For each signal, compute F3 entry + all technical levels. Returns enriched df."""
    print("\nEnriching signals with F3 entries and technical levels...")
    print("(this loads daily cache for each symbol — first time is slow)")

    enriched = []
    n_total = len(paths_df)
    t0 = time.time()
    n_no_daily = 0
    n_no_entry = 0

    for idx, sig in paths_df.iterrows():
        if (idx + 1) % 500 == 0:
            elapsed = time.time() - t0
            rate = (idx + 1) / elapsed
            eta = (n_total - idx - 1) / rate if rate > 0 else 0
            print(f"  [{idx + 1}/{n_total}] elapsed={elapsed / 60:.1f}m  "
                  f"ETA={eta / 60:.1f}m  enriched={len(enriched)}  "
                  f"no_daily={n_no_daily}  no_entry={n_no_entry}")

        # F3 entry
        entry_idx, entry_price = get_f3_entry(sig)
        if entry_idx is None:
            n_no_entry += 1
            continue

        # Trade simulation (baseline F3)
        trade = simulate_f3_trade(sig, entry_idx, entry_price)
        if trade is None:
            continue

        # Compute context
        bar_ts = pd.to_datetime(sig["bar_timestamps"], unit="ns")
        entry_ts = bar_ts[entry_idx]
        if entry_ts.tz is None:
            entry_ts_ist = entry_ts.tz_localize(IST)
        else:
            entry_ts_ist = entry_ts.tz_convert(IST)

        # Gap pct
        prev_close_intraday = sig.get("prev_close", 0)
        day0_open = sig.get("d1_open", 0)
        gap_pct = ((day0_open / prev_close_intraday - 1) * 100
                   if prev_close_intraday > 0 and day0_open > 0 else 0)

        # VWAP
        vwap = compute_vwap_at_entry(sig, entry_idx)
        entry_vs_vwap_pct = ((entry_price / vwap - 1) * 100) if vwap > 0 else 0

        # VPOC (computationally heavier — skip if too expensive)
        vpoc = compute_vpoc_at_entry(sig, entry_idx)
        entry_vs_vpoc_pct = ((entry_price / vpoc - 1) * 100) if vpoc and vpoc > 0 else 0

        # Daily levels (CPR, pivots, MA)
        levels = compute_levels_for_signal(sig["symbol"], sig["signal_date"])
        if not levels:
            n_no_daily += 1
            # Still keep the trade but mark levels as missing
            levels = {"pivot": np.nan, "tc": np.nan, "bc": np.nan, "cpr_width_pct": np.nan,
                      "r1": np.nan, "r2": np.nan, "s1": np.nan, "s2": np.nan,
                      "pdh": np.nan, "pdl": np.nan, "ma20": np.nan,
                      "dist_from_ma20_pct": np.nan}

        # Compute relative positions
        pivot = levels.get("pivot", np.nan)
        tc = levels.get("tc", np.nan)
        pdh = levels.get("pdh", np.nan)
        r1 = levels.get("r1", np.nan)

        enriched.append({
            "symbol": sig["symbol"],
            "signal_date": sig["signal_date"],
            "regime": sig["regime"],
            "probability": sig["probability"],
            "entry_time": entry_ts_ist,
            "entry_price": entry_price,
            "time_of_day": entry_ts_ist.hour + entry_ts_ist.minute / 60.0,
            "gap_pct": gap_pct,
            "vwap": vwap,
            "entry_vs_vwap_pct": entry_vs_vwap_pct,
            "vpoc": vpoc if vpoc else 0,
            "entry_vs_vpoc_pct": entry_vs_vpoc_pct,
            **levels,
            "entry_above_pivot": (entry_price > pivot) if not pd.isna(pivot) else None,
            "entry_above_tc": (entry_price > tc) if not pd.isna(tc) else None,
            "entry_above_pdh": (entry_price > pdh) if not pd.isna(pdh) else None,
            "entry_above_r1": (entry_price > r1) if not pd.isna(r1) else None,
            **trade,
        })

    print(f"\n  Enriched: {len(enriched)} signals  "
          f"(missing daily: {n_no_daily}, no F3 entry: {n_no_entry})")
    return pd.DataFrame(enriched)


# =============================================================================
# FILTER TESTING
# =============================================================================

def apply_filter_combo(enriched_df, filter_spec):
    """Apply a filter specification to enriched df. Returns filtered df."""
    df = enriched_df.copy()

    for filter_name, filter_args in filter_spec.items():
        if filter_name == "vwap_above":
            if filter_args.get("required", True):
                df = df[df["entry_vs_vwap_pct"] > filter_args.get("min", 0)]
            else:
                df = df[df["entry_vs_vwap_pct"] < filter_args.get("max", 0)]
        elif filter_name == "gap_max":
            df = df[df["gap_pct"] <= filter_args]
        elif filter_name == "gap_min":
            df = df[df["gap_pct"] >= filter_args]
        elif filter_name == "above_pivot":
            df = df[df["entry_above_pivot"] == True]
        elif filter_name == "above_tc":
            df = df[df["entry_above_tc"] == True]
        elif filter_name == "above_pdh":
            df = df[df["entry_above_pdh"] == True]
        elif filter_name == "above_r1":
            df = df[df["entry_above_r1"] == True]
        elif filter_name == "above_vpoc":
            df = df[df["entry_vs_vpoc_pct"] > filter_args.get("min", 0)]
        elif filter_name == "dist_ma_max":
            df = df[df["dist_from_ma20_pct"].abs() <= filter_args]
        elif filter_name == "dist_ma_min":
            df = df[df["dist_from_ma20_pct"] >= filter_args]
        elif filter_name == "cpr_width_max":
            df = df[df["cpr_width_pct"] <= filter_args]
        elif filter_name == "cpr_width_min":
            df = df[df["cpr_width_pct"] >= filter_args]
        elif filter_name == "time_range":
            t_min, t_max = filter_args
            df = df[(df["time_of_day"] >= t_min) & (df["time_of_day"] <= t_max)]
        elif filter_name == "prob_min":
            df = df[df["probability"] >= filter_args]
        elif filter_name == "regime":
            if isinstance(filter_args, str):
                df = df[df["regime"] == filter_args]
            else:
                df = df[df["regime"].isin(filter_args)]

    return df


def compute_metrics(df, label):
    if len(df) < MIN_TRADES_FOR_REPORT:
        return {"label": label, "n_trades": len(df), "INSUFFICIENT": True}

    returns = df["net_ret_pct"].values
    wins = returns > 0

    return {
        "label": label,
        "n_trades": len(df),
        "win_rate_pct": round(100 * wins.mean(), 2),
        "avg_ret_pct": round(returns.mean(), 3),
        "std_pct": round(returns.std(), 3),
        "sharpe_annual": round(returns.mean() / (returns.std() + 1e-9) * np.sqrt(SHARPE_PERIODS_PER_YEAR), 2),
        "max_loss": round(returns.min(), 2),
        "max_win": round(returns.max(), 2),
        "avg_mae": round(df["mae_pct"].mean(), 2),
        "avg_mfe": round(df["mfe_pct"].mean(), 2),
        "avg_days": round(df["days_held"].mean(), 2),
        "INSUFFICIENT": False,
    }


# =============================================================================
# MAIN
# =============================================================================

def main():
    print("=" * 80)
    print("STRATEGY LAB - F3 + Technical Level Filters (Tier 1+2)")
    print("=" * 80)

    if not EXTRACTED_PATHS.exists():
        print(f"FATAL: {EXTRACTED_PATHS} not found.")
        print("Run orb_workshop.py first.")
        return

    if not DAILY_CACHE_DIR.exists():
        print(f"FATAL: Daily cache dir not found: {DAILY_CACHE_DIR}")
        print("Update DAILY_CACHE_DIR in the script.")
        return

    print(f"\nLoading paths from {EXTRACTED_PATHS}")
    paths_df = pd.read_parquet(EXTRACTED_PATHS)
    print(f"  {len(paths_df):,} signal paths loaded")
    print(f"  Daily cache: {DAILY_CACHE_DIR}")

    # === Enrich (slow step, do once) ===
    enriched = enrich_signals_with_levels(paths_df)
    print(f"\n  Final enriched: {len(enriched):,} trades")

    # Save enriched for inspection
    enriched_save = enriched.copy()
    for c in enriched_save.columns:
        if pd.api.types.is_datetime64_any_dtype(enriched_save[c]):
            try:
                if enriched_save[c].dt.tz is not None:
                    enriched_save[c] = enriched_save[c].dt.tz_localize(None)
            except Exception:
                pass
    enriched_save.to_parquet(OUT_DIR / "f3_enriched_trades.parquet", index=False)

    # === Baseline F3 ===
    print("\n" + "=" * 80)
    print("BASELINE: F3 with no additional filters")
    print("=" * 80)
    baseline_m = compute_metrics(enriched, "F3_baseline")
    print(f"  n={baseline_m['n_trades']:,}  Win={baseline_m['win_rate_pct']}%  "
          f"AvgRet={baseline_m['avg_ret_pct']:+.3f}%  Sharpe={baseline_m['sharpe_annual']}")

    all_results = [baseline_m]

    # === Individual filter tests ===
    print("\n" + "=" * 80)
    print("INDIVIDUAL FILTER TESTS")
    print("=" * 80)

    individual_tests = [
        # Tier 1: VWAP
        ("VWAP: entry above VWAP", {"vwap_above": {"required": True, "min": 0}}),
        ("VWAP: entry > 0.5% above VWAP", {"vwap_above": {"required": True, "min": 0.5}}),
        ("VWAP: entry > 1% above VWAP", {"vwap_above": {"required": True, "min": 1.0}}),

        # Tier 1: Gap
        ("Gap: skip gap-up > 2%", {"gap_max": 2.0}),
        ("Gap: skip gap-up > 3%", {"gap_max": 3.0}),
        ("Gap: no gap-down (>= -0.5%)", {"gap_min": -0.5}),
        ("Gap: only mild gap-up (0.5-2%)", {"gap_min": 0.5, "gap_max": 2.0}),

        # Tier 1: MA distance
        ("MA20: not over-extended (< 10%)", {"dist_ma_max": 10.0}),
        ("MA20: above MA (positive dist)", {"dist_ma_min": 0}),
        ("MA20: range -5% to +10%", {"dist_ma_min": -5.0, "dist_ma_max": 10.0}),

        # Tier 1: CPR alignment
        ("CPR: entry above Pivot", {"above_pivot": True}),
        ("CPR: entry above TC (Top Central)", {"above_tc": True}),
        ("CPR: narrow CPR width (< 1%)", {"cpr_width_max": 1.0}),
        ("CPR: wider CPR (>= 1%)", {"cpr_width_min": 1.0}),

        # Tier 2: Pivots
        ("Pivot: entry above R1", {"above_r1": True}),
        ("Pivot: entry above PDH", {"above_pdh": True}),

        # Tier 2: VPOC
        ("VPOC: entry above VPOC", {"above_vpoc": {"min": 0}}),
        ("VPOC: entry > 0.5% above VPOC", {"above_vpoc": {"min": 0.5}}),

        # Time
        ("Time: morning only (9:30-11:00)", {"time_range": (9.5, 11.0)}),
        ("Time: skip late (< 14:00)", {"time_range": (9.5, 14.0)}),

        # Probability
        ("Prob: >= 0.85", {"prob_min": 0.85}),

        # Regime
        ("Regime: bear_trend only", {"regime": "bear_trend"}),
    ]

    for label, filter_spec in individual_tests:
        filtered = apply_filter_combo(enriched, filter_spec)
        m = compute_metrics(filtered, label)
        all_results.append(m)
        if m.get("INSUFFICIENT"):
            print(f"  {label:<50} INSUFFICIENT (n={m['n_trades']})")
        else:
            print(f"  {label:<50} n={m['n_trades']:>5,}  "
                  f"Win={m['win_rate_pct']:>5.1f}%  Avg={m['avg_ret_pct']:>+6.3f}%  "
                  f"Sharpe={m['sharpe_annual']:>5.2f}")

    # === Combination tests ===
    print("\n" + "=" * 80)
    print("COMBINATION TESTS")
    print("=" * 80)

    combo_tests = [
        ("F3 + VWAP + Gap<2%",
         {"vwap_above": {"required": True, "min": 0}, "gap_max": 2.0}),
        ("F3 + VWAP + above Pivot",
         {"vwap_above": {"required": True, "min": 0}, "above_pivot": True}),
        ("F3 + VWAP + above TC",
         {"vwap_above": {"required": True, "min": 0}, "above_tc": True}),
        ("F3 + VWAP + above PDH",
         {"vwap_above": {"required": True, "min": 0}, "above_pdh": True}),
        ("F3 + Gap<2% + above Pivot",
         {"gap_max": 2.0, "above_pivot": True}),
        ("F3 + Morning + VWAP",
         {"time_range": (9.5, 11.0), "vwap_above": {"required": True, "min": 0}}),
        ("F3 + Prob>=0.85 + VWAP",
         {"prob_min": 0.85, "vwap_above": {"required": True, "min": 0}}),
        ("F3 + Prob>=0.85 + above Pivot",
         {"prob_min": 0.85, "above_pivot": True}),
        ("F3 + Prob>=0.85 + Gap<2%",
         {"prob_min": 0.85, "gap_max": 2.0}),
        ("F3 + VWAP + Gap<2% + above Pivot (triple)",
         {"vwap_above": {"required": True, "min": 0}, "gap_max": 2.0, "above_pivot": True}),
        ("F3 + Morning + VWAP + Gap<2% (triple)",
         {"time_range": (9.5, 11.0), "vwap_above": {"required": True, "min": 0}, "gap_max": 2.0}),
        ("F3 + Prob>=0.85 + VWAP + Pivot (triple)",
         {"prob_min": 0.85, "vwap_above": {"required": True, "min": 0}, "above_pivot": True}),
        ("F3 + above PDH + above Pivot",
         {"above_pdh": True, "above_pivot": True}),
        ("F3 + bear_trend + VWAP",
         {"regime": "bear_trend", "vwap_above": {"required": True, "min": 0}}),
    ]

    for label, filter_spec in combo_tests:
        filtered = apply_filter_combo(enriched, filter_spec)
        m = compute_metrics(filtered, label)
        all_results.append(m)
        if m.get("INSUFFICIENT"):
            print(f"  {label:<50} INSUFFICIENT (n={m['n_trades']})")
        else:
            print(f"  {label:<50} n={m['n_trades']:>5,}  "
                  f"Win={m['win_rate_pct']:>5.1f}%  Avg={m['avg_ret_pct']:>+6.3f}%  "
                  f"Sharpe={m['sharpe_annual']:>5.2f}")

    # === Save outputs ===
    print("\n" + "=" * 80)
    print("SAVING OUTPUTS")
    print("=" * 80)

    results_df = pd.DataFrame([r for r in all_results if not r.get("INSUFFICIENT")])
    results_df = results_df.sort_values("sharpe_annual", ascending=False, na_position="last")

    csv_path = OUT_DIR / "strategy_lab_results.csv"
    results_df.to_csv(csv_path, index=False)

    excel_path = OUT_DIR / "strategy_lab_report.xlsx"
    with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
        # All ranked
        results_df.to_excel(writer, sheet_name="Ranked by Sharpe", index=False)

        # Individual filters
        ind_results = pd.DataFrame([r for r in all_results
                                    if not r.get("INSUFFICIENT") and
                                    any(t[0] == r["label"] for t in individual_tests)])
        ind_results.to_excel(writer, sheet_name="Individual Filters", index=False)

        # Combinations
        combo_results = pd.DataFrame([r for r in all_results
                                      if not r.get("INSUFFICIENT") and
                                      any(t[0] == r["label"] for t in combo_tests)])
        combo_results.to_excel(writer, sheet_name="Combinations", index=False)

        # Baseline
        baseline_df = pd.DataFrame([baseline_m])
        baseline_df.to_excel(writer, sheet_name="Baseline F3", index=False)

    print(f"  CSV: {csv_path}")
    print(f"  Excel: {excel_path}")
    print(f"  Enriched trades: {OUT_DIR / 'f3_enriched_trades.parquet'}")

    # === Honest summary ===
    print("\n" + "=" * 80)
    print("HONEST SUMMARY")
    print("=" * 80)

    baseline_sharpe = baseline_m["sharpe_annual"]
    valid_results = [r for r in all_results
                     if not r.get("INSUFFICIENT") and r["label"] != "F3_baseline"]

    # Find strategies that beat baseline by meaningful margin
    improvements = sorted(
        [r for r in valid_results if r["sharpe_annual"] > baseline_sharpe + 0.3],
        key=lambda r: -r["sharpe_annual"]
    )

    if improvements:
        print(f"\nStrategies that beat F3 baseline (Sharpe {baseline_sharpe}) by >0.3:")
        for r in improvements[:10]:
            diff = r["sharpe_annual"] - baseline_sharpe
            print(f"  {r['label']:<50} Sharpe={r['sharpe_annual']:>5.2f} "
                  f"(+{diff:.2f})  n={r['n_trades']:,}  Win={r['win_rate_pct']:.1f}%")
    else:
        print(f"\nNo strategies beat F3 baseline by meaningful margin.")
        print("F3 appears to be at or near its ceiling. Stop optimizing, start trading.")

    # Find big losses
    hurt = sorted(
        [r for r in valid_results if r["sharpe_annual"] < baseline_sharpe - 0.5],
        key=lambda r: r["sharpe_annual"]
    )

    if hurt:
        print(f"\nFilters that HURT performance significantly:")
        for r in hurt[:5]:
            print(f"  {r['label']:<50} Sharpe={r['sharpe_annual']:>5.2f}  "
                  f"n={r['n_trades']:,}")

    print("\n" + "=" * 80)
    print("DONE")
    print("=" * 80)


if __name__ == "__main__":
    main()