

import pyarrow.parquet as pq
print([c for c in pq.read_schema(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full\panel_cache.parquet").names if c.startswith("M_")])