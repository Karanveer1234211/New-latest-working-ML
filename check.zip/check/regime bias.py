#!/usr/bin/env python3
# =============================================================================
# REGIME SELECTION-BIAS CHECK  (diagnostic for "point 3")
# =============================================================================
#
# QUESTION
#   Does the 4-regime routed ensemble actually beat a single model, or does its
#   apparent OOS edge come from CONDITIONAL SAMPLING BIAS?
#
#   The bias: in fit_regime_ensembles(), the panel is split into 4 regime
#   subsets FIRST, and the train/cal/test split happens INSIDE each subset.
#   A row labeled bull_trend at time t only trains/evaluates against other rows
#   that were ALSO bull_trend. Stocks that *stayed* in a regime are not a random
#   sample of that regime -- so per-regime OOS metrics can look better than what
#   you get live, where regime is just today's label and tomorrow is unknown.
#
# METHOD  (everything held constant except the routing decision)
#   1. Build labels + features exactly like the model pipeline.
#   2. Compute one GLOBAL time-ordered 70/15/15 train/cal/test split on the
#      whole labeled panel. The SAME test rows are scored by every approach.
#   3. Approach A  - SINGLE model: train one LGBM on all train rows.
#   4. Approach B  - ROUTED      : train one LGBM per regime on the regime's
#                                   slice of the SAME global train window, then
#                                   score each test row with its regime's model.
#   5. Approach C  - ROUTED-SHUFFLED (placebo): identical to B, but each row's
#                                   regime label is randomly permuted before
#                                   routing. If B beats C by a lot, routing has
#                                   real structure. If B ~= C, the "edge" is an
#                                   artifact of slicing/among-bin variance.
#   6. Report AUC, Brier, and Spearman IC vs forward 5d-adj return, OVERALL and
#      WITHIN each regime bin, for A / B / C on the identical test rows.
#
#   Crucially, because the test rows are the SAME for A, B, C and the split is
#   global (not per-regime), any gap between A and B is the value of routing,
#   not the value of having pre-selected easier rows. A vs C isolates whether
#   the regime variable carries information at all.
#
# USAGE
#   python regime_bias_check.py
#   (edit PANEL_PATH / FEATURES_PATH below, or pass --panel / --features)
# =============================================================================

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score, brier_score_loss
import lightgbm as lgb

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------------------- config
BASE_DIR = Path(r"C:\Users\karanvsi\Desktop\Kite Connect\v3_2_output_full")
PANEL_PATH_DEFAULT = BASE_DIR / "panel_cache.parquet"
FEATURES_PATH_DEFAULT = BASE_DIR / "features_train.json"
OUT_DIR_DEFAULT = BASE_DIR / "regime_bias_check"

IST = "Asia/Kolkata"
RET_COL = "ret_5d_oc_pct"
TARGET_COL = "top20_vs_bot20_5d"
MIN_CLOSE = 2.0
MIN_AVG20_VOL = 200_000
SEED = 42
REGIMES = ["bull_trend", "bull_range", "bear_trend", "bear_range"]

LGB_PARAMS = dict(
    n_estimators=800,
    learning_rate=0.02,
    num_leaves=31,
    max_depth=6,
    feature_fraction=0.7,
    bagging_fraction=0.7,
    bagging_freq=1,
    min_data_in_leaf=300,
    reg_alpha=0.3,
    reg_lambda=10.0,
    n_jobs=-1,
    random_state=SEED,
    verbosity=-1,
)


# ----------------------------------------------------------------------------- helpers
def _safe(s):
    return pd.to_numeric(s, errors="coerce")


def build_label_and_regime(panel: pd.DataFrame) -> pd.DataFrame:
    """Reproduce top20_vs_bot20_5d + ret_5d_adj + stock_regime (matches model)."""
    p = panel.copy()
    p["date"] = pd.to_datetime(p["timestamp"]).dt.normalize()

    daily_ret = (_safe(p["close"]).groupby(p["symbol"], observed=True).pct_change() * 100.0)
    p["vol_20"] = (
        daily_ret.groupby(p["symbol"], observed=True)
        .rolling(20, min_periods=10).std().reset_index(level=0, drop=True)
    )
    p["atr_pct"] = (_safe(p["D_atr14"]) / _safe(p["close"])).replace([np.inf, -np.inf], np.nan) * 100.0
    vol_basis = p["vol_20"].fillna(p["atr_pct"]).replace(0.0, np.nan)
    p["ret_5d_adj"] = _safe(p[RET_COL]) / vol_basis
    p["rank_5d_pct"] = p.groupby("date")["ret_5d_adj"].rank(method="average", pct=True)
    p[TARGET_COL] = np.where(p["rank_5d_pct"] >= 0.80, 1,
                             np.where(p["rank_5d_pct"] <= 0.20, 0, np.nan))

    # stock_regime (only recompute if not already present from the model run)
    if "stock_regime" not in p.columns or p["stock_regime"].isna().all():
        close = _safe(p["close"])
        sma200 = _safe(p.get("D_sma200", np.nan))
        adx = _safe(p.get("D_adx14", np.nan))
        is_bull = close > sma200
        is_ranging = adx < 20
        regime = pd.Series("bull_trend", index=p.index, dtype="object")
        regime[is_bull & ~is_ranging] = "bull_trend"
        regime[is_bull & is_ranging] = "bull_range"
        regime[~is_bull & ~is_ranging] = "bear_trend"
        regime[~is_bull & is_ranging] = "bear_range"
        p["stock_regime"] = regime
    return p


def prepare_X(df: pd.DataFrame, feats, impute) -> pd.DataFrame:
    X = df.reindex(columns=feats).copy()
    for c in feats:
        X[c] = _safe(X[c]).fillna(impute.get(c, 0.0))
    return X


def time_split(ts_values, fr_train=0.70, fr_cal=0.15):
    """Global time-ordered split -> (train_pos, cal_pos, test_pos) into the array order."""
    order = np.argsort(ts_values)
    n = len(order)
    i1 = int(fr_train * n)
    i2 = int((fr_train + fr_cal) * n)
    return order[:i1], order[i1:i2], order[i2:]


def fit_lgbm(X_tr, y_tr, X_cal, y_cal, seed):
    params = dict(LGB_PARAMS)
    params["random_state"] = seed
    clf = lgb.LGBMClassifier(**params)
    cbs = [lgb.callback.log_evaluation(period=0)]
    if len(X_cal) >= 200:
        cbs.insert(0, lgb.callback.early_stopping(stopping_rounds=100))
        clf.fit(X_tr, y_tr, eval_set=[(X_cal, y_cal)],
                eval_metric="binary_logloss", callbacks=cbs)
    else:
        clf.fit(X_tr, y_tr, callbacks=cbs)
    return clf


def metrics(y_true, prob, ret_adj):
    out = {}
    try:
        out["auc"] = float(roc_auc_score(y_true, prob))
    except Exception:
        out["auc"] = np.nan
    try:
        out["brier"] = float(brier_score_loss(y_true, prob))
    except Exception:
        out["brier"] = np.nan
    try:
        m = np.isfinite(prob) & np.isfinite(ret_adj)
        out["ic_5d_adj"] = float(spearmanr(prob[m], ret_adj[m]).statistic) if m.sum() > 30 else np.nan
    except Exception:
        out["ic_5d_adj"] = np.nan
    out["n"] = int(len(y_true))
    out["base_rate"] = float(np.mean(y_true)) if len(y_true) else np.nan
    return out


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--panel", default=str(PANEL_PATH_DEFAULT))
    ap.add_argument("--features", default=str(FEATURES_PATH_DEFAULT))
    ap.add_argument("--out", default=str(OUT_DIR_DEFAULT))
    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("REGIME SELECTION-BIAS CHECK")
    print("=" * 70)

    panel = pd.read_parquet(args.panel)
    panel["timestamp"] = pd.to_datetime(panel["timestamp"]).dt.tz_convert(IST)
    panel = panel.sort_values(["symbol", "timestamp"]).reset_index(drop=True)
    panel["avg20_vol"] = (
        panel.groupby("symbol")["volume"]
        .transform(lambda s: s.rolling(20, min_periods=1).mean())
    )

    schema = json.loads(Path(args.features).read_text())
    feats = list(schema["features"])
    impute = {k: float(v) for k, v in schema["impute"].items()}

    panel = build_label_and_regime(panel)

    # universe filter + labeled rows only
    lab = panel[
        panel[TARGET_COL].notna()
        & (_safe(panel["close"]) >= MIN_CLOSE)
        & (panel["avg20_vol"] >= MIN_AVG20_VOL)
    ].copy().reset_index(drop=True)

    print(f"  Labeled rows         : {len(lab):,}")
    print(f"  Regime distribution  :")
    for r in REGIMES:
        nr = int((lab["stock_regime"] == r).sum())
        print(f"      {r:12} {nr:>10,}  ({100*nr/max(len(lab),1):5.2f}%)")

    X = prepare_X(lab, feats, impute)
    y = lab[TARGET_COL].astype(int).to_numpy()
    ts = pd.to_datetime(lab["timestamp"]).to_numpy()
    reg = lab["stock_regime"].to_numpy()
    ret_adj = _safe(lab["ret_5d_adj"]).to_numpy()

    # ----- ONE global time split, shared by every approach -----
    tr, cal, te = time_split(ts)
    print(f"\n  Global split (shared): train={len(tr):,}  cal={len(cal):,}  test={len(te):,}")
    test_cut = pd.Timestamp(ts[te].min())
    print(f"  Test window starts   : {test_cut.date()}")

    Xtr, ytr = X.iloc[tr], y[tr]
    Xcal, ycal = X.iloc[cal], y[cal]
    Xte, yte = X.iloc[te], y[te]
    reg_te = reg[te]
    ret_te = ret_adj[te]

    # =====================================================================
    # APPROACH A — SINGLE MODEL (all train rows, no routing)
    # =====================================================================
    print("\n[A] Single model (no routing)...")
    clf_single = fit_lgbm(Xtr, ytr, Xcal, ycal, seed=SEED)
    prob_A = clf_single.predict_proba(Xte)[:, 1]

    # =====================================================================
    # APPROACH B — ROUTED (per-regime model trained on global train window)
    # =====================================================================
    print("[B] Routed ensemble (per-regime, same global window)...")
    reg_tr = reg[tr]
    reg_cal = reg[cal]
    regime_models = {}
    for r in REGIMES:
        m_tr = reg_tr == r
        m_cal = reg_cal == r
        if m_tr.sum() < 2000 or ytr[m_tr].sum() < 100:
            print(f"      {r:12} insufficient train rows ({int(m_tr.sum())}) -> falls back to single")
            regime_models[r] = clf_single
            continue
        regime_models[r] = fit_lgbm(
            Xtr.iloc[m_tr], ytr[m_tr],
            Xcal.iloc[m_cal] if m_cal.sum() else Xcal,
            ycal[m_cal] if m_cal.sum() else ycal,
            seed=SEED + hash(r) % 1000,
        )
    prob_B = np.full(len(Xte), np.nan)
    for r in REGIMES:
        mask = reg_te == r
        if mask.any():
            prob_B[mask] = regime_models[r].predict_proba(Xte.iloc[mask])[:, 1]
    # any leftover -> single
    leftover = ~np.isfinite(prob_B)
    if leftover.any():
        prob_B[leftover] = clf_single.predict_proba(Xte.iloc[leftover])[:, 1]

    # =====================================================================
    # APPROACH C — ROUTED, REGIME LABELS SHUFFLED (placebo)
    # =====================================================================
    print("[C] Routed with SHUFFLED regime labels (placebo)...")
    rng = np.random.default_rng(SEED)
    reg_tr_sh = rng.permutation(reg_tr)
    reg_cal_sh = rng.permutation(reg_cal)
    reg_te_sh = rng.permutation(reg_te)
    regime_models_sh = {}
    for r in REGIMES:
        m_tr = reg_tr_sh == r
        m_cal = reg_cal_sh == r
        if m_tr.sum() < 2000 or ytr[m_tr].sum() < 100:
            regime_models_sh[r] = clf_single
            continue
        regime_models_sh[r] = fit_lgbm(
            Xtr.iloc[m_tr], ytr[m_tr],
            Xcal.iloc[m_cal] if m_cal.sum() else Xcal,
            ycal[m_cal] if m_cal.sum() else ycal,
            seed=SEED + 7 + hash(r) % 1000,
        )
    prob_C = np.full(len(Xte), np.nan)
    for r in REGIMES:
        mask = reg_te_sh == r
        if mask.any():
            prob_C[mask] = regime_models_sh[r].predict_proba(Xte.iloc[mask])[:, 1]
    leftover = ~np.isfinite(prob_C)
    if leftover.any():
        prob_C[leftover] = clf_single.predict_proba(Xte.iloc[leftover])[:, 1]

    # =====================================================================
    # REPORT
    # =====================================================================
    print("\n" + "=" * 70)
    print("RESULTS  (identical test rows for A / B / C)")
    print("=" * 70)

    rows = []

    def add(scope, approach, prob, mask=None):
        if mask is None:
            mask = np.ones(len(yte), dtype=bool)
        mt = metrics(yte[mask], prob[mask], ret_te[mask])
        mt.update({"scope": scope, "approach": approach})
        rows.append(mt)

    add("OVERALL", "A_single", prob_A)
    add("OVERALL", "B_routed", prob_B)
    add("OVERALL", "C_routed_shuffled", prob_C)
    for r in REGIMES:
        mask = reg_te == r
        if mask.sum() < 50:
            continue
        add(r, "A_single", prob_A, mask)
        add(r, "B_routed", prob_B, mask)
        add(r, "C_routed_shuffled", prob_C, mask)

    res = pd.DataFrame(rows)[
        ["scope", "approach", "n", "base_rate", "auc", "brier", "ic_5d_adj"]
    ]
    res[["base_rate", "auc", "brier", "ic_5d_adj"]] = res[
        ["base_rate", "auc", "brier", "ic_5d_adj"]
    ].round(4)

    pd.set_option("display.width", 140)
    print(res.to_string(index=False))
    res.to_csv(out_dir / "regime_bias_results.csv", index=False)

    # ----- verdict -----
    ov = res[res["scope"] == "OVERALL"].set_index("approach")
    auc_A = ov.loc["A_single", "auc"]
    auc_B = ov.loc["B_routed", "auc"]
    auc_C = ov.loc["C_routed_shuffled", "auc"]

    print("\n" + "-" * 70)
    print("INTERPRETATION")
    print("-" * 70)
    print(f"  AUC  single (A)         : {auc_A:.4f}")
    print(f"  AUC  routed (B)         : {auc_B:.4f}   (B - A = {auc_B-auc_A:+.4f})")
    print(f"  AUC  routed-shuffled(C) : {auc_C:.4f}   (B - C = {auc_B-auc_C:+.4f})")
    print()
    if (auc_B - auc_A) <= 0.001:
        print("  -> Routing does NOT beat a single model on the SAME test rows.")
        print("     Any per-regime OOS edge in the production run is most likely")
        print("     the conditional-sampling artifact, not real signal.")
    elif (auc_B - auc_C) <= 0.002:
        print("  -> Routing beats single, but a RANDOM regime label routes just")
        print("     as well (B ~= C). The gain comes from training on subsets,")
        print("     not from the regime variable carrying information. Suspect bias.")
    else:
        print("  -> Routing beats BOTH single (A) and shuffled-regime (C).")
        print("     The regime variable carries genuine, route-able information.")
        print("     The production edge is likely real, not pure selection bias.")
    print("\n  Saved: regime_bias_results.csv")
    print("  NOTE: also compare per-regime rows above. A regime where A >> B on")
    print("        the SAME rows is a regime whose production metric is inflated.")


if __name__ == "__main__":
    main()